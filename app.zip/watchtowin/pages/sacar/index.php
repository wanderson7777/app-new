<!------------ init includes ----------->
<?php $page_name = 'Login'; ?>
<?php include('../../app/sql_conection.php'); ?>
<?php include('../../app/app_vars.php'); ?>
<?php include('../../app/user_vars.php'); ?>
<?php include('../../app/bootstrap.php'); ?>
<!----------- finish includes ---------->

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="style.css">
  <!-- <meta http-equiv="refresh" content="0"> -->
</head>
<body>
  <div class="box_login">
    <div class="container">
      <div class="row">
        <div class="col-6">
          <a href="../dashboard/"><label class="back"><i class="fa-solid fa-rotate-left"></i>  Voltar</label></a>
        </div>
        <div class="col-6">
          <label style="float: right;" class="saldo"><i class="fa-solid fa-arrow-trend-up"></i>  R$ <?php echo number_format($user_balance,2,",",".") ?></label>
        </div>
        <center><h1>Solicitação de Saque</h1></center>
        <form action="./verify.php" method="POST">
          <label class="description">Insira apenas números, ex: 2500</label>
          <input type="hidden" name="client_id">
          <input placeholder="R$ 0,00 (Insira o valor)" type="number" name="valor"><br>
          <button name="entrar">Próximo</button>
        </form>
      </div>
      <div class="row">
      </div>
    </div>
  </div>
</body>
</html>