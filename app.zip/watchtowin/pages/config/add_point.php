<?php 

	$confirmation = 'true';

	while ($confirmation = 'true') {
		sleep(5);
		echo 'ce';
		echo '<br>';
		sleep(5);
	}

 ?>