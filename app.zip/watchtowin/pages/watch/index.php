<?php 

mysqli_connect('localhost','root','');
mysqli_select_db("watchtowin");
mysql_query("UPDATE usuarios SET saldo=saldo+1 WHERE cpf=cpf");

$result = mysql_query("SELECT FROM usuarios WHERE cpf=cpf");
while ($row = mysql_fetch_array ($result)) {
    echo "cpc: ".$row['value'];
}


?>