
<?php $link = 'https://www.google.com'; ?>
<script type="text/javascript">window.open('<?php echo $link ?>');</script>

<?php 
    
    $var = 1;
    while() { 
        $var = $var + 1;
    }
    echo $var;

?>
