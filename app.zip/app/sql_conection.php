<?php 

$conn = mysqli_connect('localhost:3306','sleepe56_apt','estudio@pride');
$db = mysqli_select_db($conn, 'sleepe56_apptiktok');

?>